import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from lightgbm import LGBMRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import BayesianRidge, Lasso, Ridge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor

plt.rcParams['savefig.dpi'] = 1500

# 1. 数据准备
file_path = (
    r"E:\Manuscript\Environmental Pollution-Reviewer\Supplementary\all Sample-all Feature.xlsx"
)
df = pd.read_excel(file_path)

feature_cols = [
    'Risk Score',
    'Economy',
    'Population',
    'Human_ABX',
    'Animal_ABX',
    'AMR_System',
    'UHC_Service_Coverage_Index',
    'Vaccinated_against_TB',
    'Physicians(1000 people)',
    'CHE-GDP',
]

X = df[feature_cols]
y_original = df['DALYs']
y_log = np.log1p(y_original)
groups = df['Region_Group_Fold']

models = {
    'DecisionTree': Pipeline([
        ('scaler', StandardScaler()),
        ('model', DecisionTreeRegressor(random_state=42)),
    ]),
    'RandomForest': Pipeline([
        ('scaler', StandardScaler()),
        ('model', RandomForestRegressor(n_estimators=100, random_state=42)),
    ]),
    'SVR': Pipeline([
        ('scaler', StandardScaler()),
        ('model', SVR(C=1.0, epsilon=0.1)),
    ]),
    'KNN': Pipeline([
        ('scaler', StandardScaler()),
        ('model', KNeighborsRegressor(n_neighbors=5)),
    ]),
    'BayesianRidge': Pipeline([
        ('scaler', StandardScaler()),
        ('model', BayesianRidge()),
    ]),
    'Ridge': Pipeline([
        ('scaler', StandardScaler()),
        ('model', Ridge(alpha=1.0)),
    ]),
    'LASSO': Pipeline([
        ('scaler', StandardScaler()),
        ('model', Lasso(alpha=1.0)),
    ]),
    'LightGBM': Pipeline([
        ('scaler', StandardScaler()),
        (
            'model',
            LGBMRegressor(n_estimators=100, verbose=-1, random_state=42),
        ),
    ]),
    'XGBoost': Pipeline([
        ('scaler', StandardScaler()),
        ('model', XGBRegressor(n_estimators=100, verbosity=0, random_state=42)),
    ]),
}

# --- 步骤 1: 交叉验证、指标计算与散点图 ---
gkf = GroupKFold(n_splits=5)
performance_dict = {}
metrics_results = []
cv_predictions_log = {}

fig, axes = plt.subplots(3, 3, figsize=(16, 16), constrained_layout=True)
axes = axes.flatten()

print('开始 5-Fold GroupKFold 交叉验证...')

for i, (name, model) in enumerate(models.items()):
    y_pred_cv_log = np.zeros_like(y_log, dtype=float)

    for train_idx, test_idx in gkf.split(X, y_log, groups=groups):
        model.fit(X.iloc[train_idx], y_log.iloc[train_idx])
        y_pred_cv_log[test_idx] = model.predict(X.iloc[test_idx])

    r2_cv = r2_score(y_log, y_pred_cv_log)
    rmse_cv = np.sqrt(mean_squared_error(y_log, y_pred_cv_log))

    performance_dict[name] = r2_cv
    metrics_results.append({'Model': name, 'Log_R2': r2_cv, 'Log_RMSE': rmse_cv})
    cv_predictions_log[name] = y_pred_cv_log.copy()

    y_true_inv = np.expm1(y_log)
    y_pred_inv = np.expm1(y_pred_cv_log)

    ax = axes[i]
    ax.scatter(y_true_inv, y_pred_inv, alpha=0.5, color='#5DADE2', edgecolor='none')
    ax.set_xscale('symlog', linthresh=1.0)
    ax.set_yscale('symlog', linthresh=1.0)

    all_vals = np.concatenate([y_true_inv, y_pred_inv])
    xmin, xmax = 0.0, all_vals.max() * 1.2

    ax.set_xlim([xmin, xmax])
    ax.set_ylim([xmin, xmax])
    ax.plot([xmin, xmax], [xmin, xmax], 'r--', lw=2, zorder=3)

    ax.set_title(f'{name}', fontsize=12, fontweight='bold', pad=15)
    ax.text(
        0.5,
        1.0,
        f'R² : {r2_cv:.3f} | RMSE : {rmse_cv:.3f}',
        fontsize=10,
        ha='center',
        va='bottom',
        transform=ax.transAxes,
    )

    ax.set_xlabel('Observed DALYs', fontsize=10)
    ax.set_ylabel('Predicted DALYs', fontsize=10)
    ax.grid(True, which='major', linestyle=':', linewidth=0.8, alpha=0.7)
    ax.grid(False, which='minor')

plt.show()

metrics_df = pd.DataFrame(metrics_results)

print('\n' + '=' * 50)
print(' 模型性能对比汇总（对数尺度 Log-DALYs） ')
print('=' * 50)
print(metrics_df.to_string(index=False))
print('=' * 50)

# --- 步骤 2: 最优模型特征重要性 ---
best_name = max(performance_dict, key=performance_dict.get)
print(f'\n最优模型为 (基于对数尺度 R2): {best_name}')

best_model = models[best_name].fit(X, y_log)

plt.figure(figsize=(8, 5))

regressor = best_model.named_steps['model']
scaler = best_model.named_steps['scaler']

if best_name == 'LightGBM':
    imp = regressor.booster_.feature_importance(importance_type='gain')
    xlabel_text = 'Total Gain (Importance)'
elif hasattr(regressor, 'feature_importances_'):
    imp = regressor.feature_importances_
    xlabel_text = 'Importance'
elif hasattr(regressor, 'coef_'):
    imp = np.abs(regressor.coef_)
    xlabel_text = 'Absolute Coefficient'
else:
    imp = permutation_importance(
        best_model, X, y_log, n_repeats=10, random_state=42
    ).importances_mean
    xlabel_text = 'Permutation Importance'

sorted_idx = np.argsort(imp)

plt.barh(np.array(feature_cols)[sorted_idx], imp[sorted_idx], color='teal')
plt.title(
    f'Feature Importance ({best_name} - Gain)'
    if best_name == 'LightGBM'
    else f'Feature Importance ({best_name})',
    fontsize=12,
    fontweight='bold',
)
plt.xlabel(xlabel_text, fontsize=10)
plt.ylabel('Features', fontsize=10)
plt.tight_layout()
plt.show()

# --- 步骤 3: SHAP 蜂群图 ---
print('正在计算 SHAP 值...')

X_scaled_df = pd.DataFrame(scaler.transform(X), columns=feature_cols)

plt.figure(figsize=(8, 6))

if best_name in ['RandomForest', 'DecisionTree', 'LightGBM', 'XGBoost']:
    explainer = shap.TreeExplainer(regressor)
    shap_values = explainer.shap_values(X_scaled_df)
    shap.summary_plot(shap_values, X_scaled_df, show=False)

elif best_name in ['Ridge', 'LASSO', 'BayesianRidge']:
    explainer = shap.LinearExplainer(regressor, X_scaled_df)
    shap_values = explainer.shap_values(X_scaled_df)
    shap.summary_plot(shap_values, X_scaled_df, show=False)

else:
    explainer = shap.KernelExplainer(best_model.predict, shap.sample(X, 50, random_state=42))
    shap_values = explainer.shap_values(X)
    shap.summary_plot(shap_values, X, show=False)

plt.title(f'SHAP Summary Plot ({best_name})', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.show()

# --- 步骤 4: SHAP 热图 ---
print('正在绘制 SHAP heatmap...')

if isinstance(shap_values, list):
    shap_values_for_heatmap = shap_values[0]
else:
    shap_values_for_heatmap = shap_values

expected_value = explainer.expected_value
if isinstance(expected_value, (list, np.ndarray)):
    expected_value = expected_value[0]

if best_name in [
    'RandomForest',
    'DecisionTree',
    'LightGBM',
    'XGBoost',
    'Ridge',
    'LASSO',
    'BayesianRidge',
]:
    shap_exp = shap.Explanation(
        values=shap_values_for_heatmap,
        base_values=np.repeat(expected_value, X_scaled_df.shape[0]),
        data=X_scaled_df.values,
        feature_names=feature_cols,
    )
else:
    shap_exp = shap.Explanation(
        values=shap_values_for_heatmap,
        base_values=np.repeat(expected_value, X.shape[0]),
        data=X.values,
        feature_names=feature_cols,
    )

plt.figure(figsize=(10, 6))
shap.plots.heatmap(shap_exp, max_display=len(feature_cols), show=False)
plt.title(f'SHAP Heatmap ({best_name})', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.show()

# --- 步骤 5: 导出每个样本的真实值和预测值 ---
print('正在导出每个样本的 True_DALYs 和 Predicted_DALYs...')

best_pred_log = cv_predictions_log[best_name]
best_pred_dalys = np.expm1(best_pred_log)

export_cols = [
    'Samples',
    'Country',
    'WDI Class',
    'WHO Class',
    'WOAH Class',
    'Year',
    'ARG',
    'Pathogen',
    'MGE',
]

export_df = df[export_cols].copy()
export_df['True_DALYs'] = y_original.values
export_df['Predicted_DALYs'] = best_pred_dalys

output_path = (
    r"E:\Manuscript\Environmental Pollution-Reviewer\Supplementary\Global Predicted DALYs.xlsx"
)

export_df.to_excel(output_path, index=False)

print(f'预测结果已保存至: {output_path}')