import pandas as pd
import numpy as np
import os
import warnings
import matplotlib.pyplot as plt

from sklearn.base import clone
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import BayesianRidge, Ridge, Lasso
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor

from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import cross_val_predict, KFold

warnings.filterwarnings('ignore')

# ==========================================
# 1. 路径设置与数据读取
# ==========================================
train_path = r"F:\Global Samples\Model Data\2026-08-25_Feature Select\7Train-3Test-Final\02.dataset\02.1-3Economy-XDR-Trainset.xlsx"
test_path = r"F:\Global Samples\Model Data\2026-08-25_Feature Select\7Train-3Test-Final\02.dataset\02.1-3Economy-XDR-Testset.xlsx"
feature_path = r"F:\Global Samples\Model Data\2026-08-25_Feature Select\7Train-3Test-Final\03.Elasticnet-123E\Elasticnet-XDR.xlsx"
output_dir = r"E:\Manuscript\Environmental Pollution-Reviewer\Best-Model\123E-XDR"

os.makedirs(output_dir, exist_ok=True)

df_train = pd.read_excel(train_path, index_col=0)
df_test = pd.read_excel(test_path, index_col=0)

df_train.columns = df_train.columns.str.strip()
df_test.columns = df_test.columns.str.strip()

selected_features_df = pd.read_excel(feature_path)
selected_features_df['Feature'] = selected_features_df['Feature'].astype(str).str.strip()
all_ordered_features = selected_features_df['Feature'].tolist()

target_col = df_train.columns[-1]

y_train_raw = df_train[target_col].astype(float).values
y_test_raw = df_test[target_col].astype(float).values

# 模型训练和评价使用 log1p(y)，但图中坐标显示原始 DALYs
y_train = np.log1p(y_train_raw)
y_test = np.log1p(y_test_raw)

models = {
    "DecisionTree": DecisionTreeRegressor(random_state=42),
    "RandomForest": RandomForestRegressor(n_estimators=100, random_state=42),
    "SVR": SVR(C=1.0, epsilon=0.1),
    "KNN": KNeighborsRegressor(n_neighbors=3),
    "BayesianRidge": BayesianRidge(),
    "Ridge": Ridge(alpha=1.0),
    "LASSO": Lasso(alpha=0.1),
    "LightGBM": LGBMRegressor(n_estimators=100, verbose=-1, random_state=42),
    "XGBoost": XGBRegressor(n_estimators=100, verbosity=0, random_state=42)
}

kf = KFold(n_splits=5, shuffle=True, random_state=42)


# ==========================================
# 2. CV评价函数：pooled OOF R2 + 每折R2
# ==========================================
def evaluate_cv_model(model, X, y, cv):
    """
    返回：
    pooled OOF R2/RMSE：所有OOF预测合并后整体计算
    fold R2/RMSE：每一折单独计算
    """
    y_pred_oof = np.zeros_like(y, dtype=float)

    fold_records = []

    for fold_id, (train_idx, valid_idx) in enumerate(cv.split(X, y), start=1):
        fold_model = clone(model)
        fold_model.fit(X[train_idx], y[train_idx])

        y_valid_pred = fold_model.predict(X[valid_idx])
        y_pred_oof[valid_idx] = y_valid_pred

        fold_r2 = r2_score(y[valid_idx], y_valid_pred)
        fold_mse = mean_squared_error(y[valid_idx], y_valid_pred)
        fold_rmse = np.sqrt(fold_mse)

        fold_records.append({
            'Fold': fold_id,
            'Fold_R2': fold_r2,
            'Fold_RMSE': fold_rmse
        })

    pooled_r2 = r2_score(y, y_pred_oof)
    pooled_mse = mean_squared_error(y, y_pred_oof)
    pooled_rmse = np.sqrt(pooled_mse)

    fold_df = pd.DataFrame(fold_records)

    return {
        'y_pred_oof': y_pred_oof,
        'pooled_r2': pooled_r2,
        'pooled_rmse': pooled_rmse,
        'fold_df': fold_df,
        'mean_fold_r2': fold_df['Fold_R2'].mean(),
        'sd_fold_r2': fold_df['Fold_R2'].std(ddof=1),
        'mean_fold_rmse': fold_df['Fold_RMSE'].mean(),
        'sd_fold_rmse': fold_df['Fold_RMSE'].std(ddof=1),
    }


# ==========================================
# 3. 渐进式特征筛选：选择 pooled OOF R2 最高的特征集
# ==========================================
iteration_results = []
all_model_search_results = []
search_fold_results = []

print("正在执行 15-50 个特征的渐进式筛选...")
print("特征筛选标准：pooled OOF R² 最高")

for k in range(15, 56):
    current_features = all_ordered_features[:k]
    X_train_sub = df_train[current_features].values

    best_k_r2 = -np.inf
    best_k_model = ""
    best_k_rmse = np.nan
    best_k_mean_fold_r2 = np.nan
    best_k_sd_fold_r2 = np.nan

    for name, model in models.items():
        try:
            cv_result = evaluate_cv_model(model, X_train_sub, y_train, kf)

            pooled_r2 = cv_result['pooled_r2']
            pooled_rmse = cv_result['pooled_rmse']

            all_model_search_results.append({
                'Feature_Count': k,
                'Model': name,
                'Pooled_OOF_R2': pooled_r2,
                'Pooled_OOF_RMSE': pooled_rmse,
                'Mean_Fold_R2': cv_result['mean_fold_r2'],
                'SD_Fold_R2': cv_result['sd_fold_r2'],
                'Mean_Fold_RMSE': cv_result['mean_fold_rmse'],
                'SD_Fold_RMSE': cv_result['sd_fold_rmse'],
            })

            fold_df = cv_result['fold_df'].copy()
            fold_df.insert(0, 'Feature_Count', k)
            fold_df.insert(1, 'Model', name)
            search_fold_results.append(fold_df)

            if pooled_r2 > best_k_r2:
                best_k_r2 = pooled_r2
                best_k_rmse = pooled_rmse
                best_k_model = name
                best_k_mean_fold_r2 = cv_result['mean_fold_r2']
                best_k_sd_fold_r2 = cv_result['sd_fold_r2']

        except Exception as e:
            print(f"特征数 {k}, 模型 {name} 运行失败: {e}")
            continue

    iteration_results.append({
        'Feature_Count': k,
        'Best_Method': best_k_model,
        'Best_Pooled_OOF_R2': best_k_r2,
        'Best_Pooled_OOF_RMSE': best_k_rmse,
        'Best_Mean_Fold_R2': best_k_mean_fold_r2,
        'Best_SD_Fold_R2': best_k_sd_fold_r2,
    })

    print(
        f"特征数 {k}: 最佳方法 {best_k_model}, "
        f"Pooled OOF R² {best_k_r2:.4f}, "
        f"Mean fold R² {best_k_mean_fold_r2:.4f} ± {best_k_sd_fold_r2:.4f}"
    )

iteration_df = pd.DataFrame(iteration_results)
all_model_search_df = pd.DataFrame(all_model_search_results)
search_fold_df = pd.concat(search_fold_results, ignore_index=True)

best_overall = iteration_df.loc[iteration_df['Best_Pooled_OOF_R2'].idxmax()]
opt_k = int(best_overall['Feature_Count'])
opt_features = all_ordered_features[:opt_k]

print(f"\n最佳组合已找到：特征数 = {opt_k}")
print(f"训练集内部最佳模型：{best_overall['Best_Method']}")
print(f"训练集内部最佳 pooled OOF R²：{best_overall['Best_Pooled_OOF_R2']:.4f}")
print(
    f"对应 mean fold R² ± SD："
    f"{best_overall['Best_Mean_Fold_R2']:.4f} ± {best_overall['Best_SD_Fold_R2']:.4f}"
)

X_final_train = df_train[opt_features].values
X_final_test = df_test[opt_features].values


# ==========================================
# 4. 绘图函数：真实值尺度 + 对数坐标
# ==========================================
def plot_observed_predicted(ax, y_obs_raw, y_pred_raw, title, color, r2_value, rmse_value):
    y_obs_plot = np.asarray(y_obs_raw, dtype=float)
    y_pred_plot = np.asarray(y_pred_raw, dtype=float)

    positive_values = np.concatenate([
        y_obs_plot[y_obs_plot > 0],
        y_pred_plot[y_pred_plot > 0]
    ])

    mn = positive_values.min()
    mx = positive_values.max()

    eps = mn * 0.5
    y_obs_plot = np.where(y_obs_plot <= 0, eps, y_obs_plot)
    y_pred_plot = np.where(y_pred_plot <= 0, eps, y_pred_plot)

    ax.scatter(y_obs_plot, y_pred_plot, alpha=0.6, s=50, color=color)
    ax.plot([mn, mx], [mn, mx], 'r--', lw=2)

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlim(mn, mx)
    ax.set_ylim(mn, mx)

    ax.set_title(title, fontsize=16, fontweight='bold', pad=25)
    ax.text(
        0.5, 1.03,
        f"R²: {r2_value:.3f} | RMSE: {rmse_value:.3f}",
        fontsize=13,
        ha='center',
        va='bottom',
        transform=ax.transAxes
    )

    ax.set_xlabel("Observed DALYs", fontsize=12)
    ax.set_ylabel("Predicted DALYs", fontsize=12)
    ax.grid(True, linestyle=':', alpha=0.45, which='major')
    ax.grid(False, which='minor')


# ==========================================
# 5. 第一张图：训练集 5-fold OOF预测，淡蓝色
# ==========================================
fig_train, axes_train = plt.subplots(3, 3, figsize=(24, 22))
axes_train = axes_train.flatten()

train_metrics = []
final_train_fold_results = []

for i, (name, model) in enumerate(models.items()):
    cv_result = evaluate_cv_model(model, X_final_train, y_train, kf)

    y_train_pred_log = cv_result['y_pred_oof']
    r2_train = cv_result['pooled_r2']
    rmse_train = cv_result['pooled_rmse']

    y_train_pred_raw = np.expm1(y_train_pred_log)
    y_train_pred_raw = np.clip(y_train_pred_raw, a_min=0, a_max=None)

    train_metrics.append({
        'Model': name,
        'Train_Pooled_OOF_R2': r2_train,
        'Train_Pooled_OOF_RMSE': rmse_train,
        'Train_Mean_Fold_R2': cv_result['mean_fold_r2'],
        'Train_SD_Fold_R2': cv_result['sd_fold_r2'],
        'Train_Mean_Fold_RMSE': cv_result['mean_fold_rmse'],
        'Train_SD_Fold_RMSE': cv_result['sd_fold_rmse'],
    })

    fold_df = cv_result['fold_df'].copy()
    fold_df.insert(0, 'Model', name)
    final_train_fold_results.append(fold_df)

    plot_observed_predicted(
        ax=axes_train[i],
        y_obs_raw=y_train_raw,
        y_pred_raw=y_train_pred_raw,
        title=name,
        color='#5DADE2',
        r2_value=r2_train,
        rmse_value=rmse_train
    )

plt.subplots_adjust(
    left=0.07,
    right=0.98,
    bottom=0.06,
    top=0.92,
    wspace=0.35,
    hspace=0.45
)

fig_train.savefig(
    os.path.join(output_dir, f"Train_CV_Top_{opt_k}_Features.png"),
    dpi=1000,
    bbox_inches='tight'
)

plt.show()


# ==========================================
# 6. 第二张图：测试集预测，绿色
# ==========================================
fig_test, axes_test = plt.subplots(3, 3, figsize=(24, 22))
axes_test = axes_test.flatten()

final_metrics = []

for i, (name, model) in enumerate(models.items()):
    final_model = clone(model)
    final_model.fit(X_final_train, y_train)

    y_test_pred_log = final_model.predict(X_final_test)

    r2_test = r2_score(y_test, y_test_pred_log)
    mse_test = mean_squared_error(y_test, y_test_pred_log)
    rmse_test = np.sqrt(mse_test)

    y_test_pred_raw = np.expm1(y_test_pred_log)
    y_test_pred_raw = np.clip(y_test_pred_raw, a_min=0, a_max=None)

    r2_test_raw = r2_score(y_test_raw, y_test_pred_raw)
    mse_test_raw = mean_squared_error(y_test_raw, y_test_pred_raw)
    rmse_test_raw = np.sqrt(mse_test_raw)

    final_metrics.append({
        'Model': name,
        'Test_R2_log': r2_test,
        'Test_MSE_log': mse_test,
        'Test_RMSE_log': rmse_test,
        'Test_R2_original': r2_test_raw,
        'Test_MSE_original': mse_test_raw,
        'Test_RMSE_original': rmse_test_raw
    })

    plot_observed_predicted(
        ax=axes_test[i],
        y_obs_raw=y_test_raw,
        y_pred_raw=y_test_pred_raw,
        title=name,
        color='#58D68D',
        r2_value=r2_test,
        rmse_value=rmse_test
    )

plt.subplots_adjust(
    left=0.07,
    right=0.98,
    bottom=0.06,
    top=0.92,
    wspace=0.35,
    hspace=0.45
)

fig_test.savefig(
    os.path.join(output_dir, f"Test_Set_Top_{opt_k}_Features.png"),
    dpi=1000,
    bbox_inches='tight'
)

plt.show()


# ==========================================
# 7. 打印最终结果
# ==========================================
print("\n" + "!" * 40)
print(f"最终最佳特征组合 (共 {opt_k} 个):")
print(opt_features)

print("-" * 40)
print("训练集 5-fold OOF 交叉验证表现:")
train_metrics_df = pd.DataFrame(train_metrics).sort_values(
    by='Train_Pooled_OOF_R2',
    ascending=False
)
print(train_metrics_df.to_string(index=False))

print("-" * 40)
print("测试集表现:")
final_metrics_df = pd.DataFrame(final_metrics).sort_values(
    by='Test_R2_log',
    ascending=False
)
print(final_metrics_df.to_string(index=False))
print("!" * 40)


# ==========================================
# 8. 保存所有结果
# ==========================================
final_train_fold_df = pd.concat(final_train_fold_results, ignore_index=True)

with pd.ExcelWriter(os.path.join(output_dir, 'Optimal_Feature_Analysis.xlsx')) as writer:
    iteration_df.to_excel(writer, sheet_name='Search_Best_By_K', index=False)
    all_model_search_df.to_excel(writer, sheet_name='Search_All_Models', index=False)
    search_fold_df.to_excel(writer, sheet_name='Search_Fold_R2', index=False)

    train_metrics_df.to_excel(writer, sheet_name='Train_CV_Performance', index=False)
    final_train_fold_df.to_excel(writer, sheet_name='Final_Feature_Fold_R2', index=False)

    final_metrics_df.to_excel(writer, sheet_name='Final_Test_Performance', index=False)
    pd.DataFrame({'Best_Features': opt_features}).to_excel(
        writer,
        sheet_name='Feature_List',
        index=False
    )

print(f"\n所有结果已保存至: {os.path.join(output_dir, 'Optimal_Feature_Analysis.xlsx')}")