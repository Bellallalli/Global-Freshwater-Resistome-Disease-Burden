from __future__ import annotations

import json
import math
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import BayesianRidge, ElasticNet, Lasso, Ridge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, cross_val_predict
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor

try:
    from lightgbm import LGBMRegressor
except ImportError:
    LGBMRegressor = None

try:
    from xgboost import XGBRegressor
except ImportError:
    XGBRegressor = None


# =============================================================================
# CONFIG
# =============================================================================
FILE_PATH = Path(r"E:\Manuscript\Environmental Pollution-Reviewer\Supplementary\FeatureSelect\00.all Samples-13ARGs-2261Subtype-352Pathogen-1280_RegionGroupKFold5.xlsx")
TARGET_COL = "MDR-TB_without_XDR"
TARGET_ALREADY_LOG1P = False

N_RESAMPLES = 1000
SUBSAMPLE_FRACTION_PER_Y_TIER = 0.80
# 15 mandatory features + 40 candidate features = 55 max features
MAX_CANDIDATES_TO_ADD = 40
ZERO_RATIO_THRESHOLD = 0.90
RANDOM_SEED = 42
COEF_ZERO_TOLERANCE = 1e-12

# 固定 alpha = 0.01 以大幅提升运行速度
FIXED_ALPHA = 0.01
ENET_L1_RATIO_GRID = [0.10, 0.30, 0.50, 0.70, 0.90, 0.95, 0.99, 1.00]

SAVEFIG_DPI = 600
SHOW_PLOTS = True

DEVELOPMENT_FOLDS = ("fold1", "fold2", "fold3", "fold4")
OUTER_TEST_FOLD = "fold5"
CANDIDATE_FIRST_COL = "Capnocytophaga gingivalis"
CANDIDATE_LAST_COL = "vancomycin__vanTN"
ALL_TARGET_COLS = ("XDR-TB", "MDR-TB_without_XDR", "MDR")

MANDATORY_FEATURES = [
    "aminoglycoside",
    "beta_lactam",
    "chloramphenicol",
    "fosfomycin",
    "macrolide-lincosamide-streptogramin",
    "multidrug",
    "polymyxin",
    "quinolone",
    "rifamycin",
    "sulfonamide",
    "tetracycline",
    "trimethoprim",
    "vancomycin",
    "Mycobacterium tuberculosis",
    "MGE",
]


def normalize_fold_labels(series: pd.Series) -> pd.Series:
    return (
        series.astype("string")
        .str.strip()
        .str.lower()
        .str.replace(r"\s+", "", regex=True)
    )


def clean_and_validate_columns(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    result.columns = result.columns.astype(str).str.strip()
    duplicated = result.columns[result.columns.duplicated()].tolist()
    if duplicated:
        raise ValueError(
            "Column names became duplicated after stripping spaces: "
            + ", ".join(map(str, duplicated[:20]))
        )
    return result


def require_columns(df: pd.DataFrame, columns: list[str] | tuple[str, ...]) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise KeyError("Missing required columns: " + ", ".join(missing))


def make_predefined_four_fold_splits(
    fold_labels: pd.Series,
) -> list[tuple[np.ndarray, np.ndarray]]:
    labels = fold_labels.to_numpy()
    splits: list[tuple[np.ndarray, np.ndarray]] = []
    for validation_fold in DEVELOPMENT_FOLDS:
        train_idx = np.flatnonzero(labels != validation_fold)
        valid_idx = np.flatnonzero(labels == validation_fold)
        if train_idx.size == 0 or valid_idx.size == 0:
            raise ValueError(
                f"Internal split {validation_fold} is empty: "
                f"train={train_idx.size}, validation={valid_idx.size}."
            )
        splits.append((train_idx, valid_idx))
    return splits


def make_feature_pipeline(estimator) -> Pipeline:
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="constant", fill_value=0.0)),
            ("scaler", StandardScaler()),
            ("model", estimator),
        ]
    )


def build_models() -> dict[str, Pipeline]:
    missing_packages = []
    if LGBMRegressor is None:
        missing_packages.append("lightgbm")
    if XGBRegressor is None:
        missing_packages.append("xgboost")
    if missing_packages:
        raise ImportError(
            "Missing packages required for the nine-model comparison: "
            + ", ".join(missing_packages)
        )
    return {
        "DecisionTree": make_feature_pipeline(
            DecisionTreeRegressor(random_state=RANDOM_SEED)
        ),
        "RandomForest": make_feature_pipeline(
            RandomForestRegressor(
                n_estimators=100,
                random_state=RANDOM_SEED,
                n_jobs=-1,
            )
        ),
        "SVR": make_feature_pipeline(SVR(C=1.0, epsilon=0.1)),
        "KNN": make_feature_pipeline(KNeighborsRegressor(n_neighbors=5)),
        "BayesianRidge": make_feature_pipeline(BayesianRidge()),
        "Ridge": make_feature_pipeline(Ridge(alpha=1.0)),
        "LASSO": make_feature_pipeline(
            Lasso(alpha=1.0, max_iter=20_000, random_state=RANDOM_SEED)
        ),
        "LightGBM": make_feature_pipeline(
            LGBMRegressor(
                n_estimators=100,
                verbose=-1,
                random_state=RANDOM_SEED,
                n_jobs=-1,
            )
        ),
        "XGBoost": make_feature_pipeline(
            XGBRegressor(
                n_estimators=100,
                verbosity=0,
                random_state=RANDOM_SEED,
                n_jobs=-1,
                objective="reg:squarederror",
            )
        ),
    }


def tune_elastic_net_l1_ratio(
    development_df: pd.DataFrame,
    elasticnet_features: list[str],
    inner_splits: list[tuple[np.ndarray, np.ndarray]],
) -> tuple[float, pd.DataFrame]:
    pipeline = make_feature_pipeline(
        ElasticNet(
            alpha=FIXED_ALPHA,
            max_iter=50_000,
            tol=1e-5,
            selection="cyclic",
        )
    )
    search = GridSearchCV(
        estimator=pipeline,
        param_grid={
            "model__l1_ratio": ENET_L1_RATIO_GRID,
        },
        scoring="neg_mean_squared_error",
        cv=inner_splits,
        n_jobs=-1,
        refit=True,
        return_train_score=False,
        error_score="raise",
    )
    search.fit(
        development_df[elasticnet_features],
        development_df["y_model"],
    )
    best_l1_ratio = float(search.best_params_["model__l1_ratio"])

    cv_results = pd.DataFrame(search.cv_results_)[
        [
            "param_model__l1_ratio",
            "mean_test_score",
            "std_test_score",
            "rank_test_score",
        ]
    ].copy()
    cv_results["Alpha"] = FIXED_ALPHA
    cv_results = cv_results.rename(
        columns={
            "param_model__l1_ratio": "L1_Ratio",
            "mean_test_score": "Mean_Neg_MSE",
            "std_test_score": "SD_Neg_MSE",
            "rank_test_score": "Rank",
        }
    ).sort_values(["Rank", "L1_Ratio"])
    return best_l1_ratio, cv_results


def create_y_tertiles(y: pd.Series) -> pd.Series:
    ranked = y.rank(method="first")
    tiers = pd.qcut(
        ranked,
        q=3,
        labels=["Low", "Medium", "High"],
    )
    if tiers.isna().any() or tiers.nunique() != 3:
        raise ValueError("Could not create three non-empty y strata.")
    return tiers


def run_stability_selection(
    development_df: pd.DataFrame,
    candidate_features: list[str],
    best_alpha: float,
    best_l1_ratio: float,
) -> pd.DataFrame:
    rng = np.random.default_rng(RANDOM_SEED)
    tier_values = development_df["y_tier"].astype(str).to_numpy()
    tier_indices = {
        tier: np.flatnonzero(tier_values == tier)
        for tier in ("Low", "Medium", "High")
    }
    for tier, indices in tier_indices.items():
        if indices.size < 2:
            raise ValueError(f"The {tier} y tier has fewer than 2 samples.")

    elasticnet_features = MANDATORY_FEATURES + candidate_features
    mandatory_count = len(MANDATORY_FEATURES)
    counts = np.zeros(len(candidate_features), dtype=np.int64)
    abs_coef_sums = np.zeros(len(candidate_features), dtype=float)

    for iteration in range(N_RESAMPLES):
        selected_parts = []
        for tier in ("Low", "Medium", "High"):
            tier_idx = tier_indices[tier]
            sample_size = max(
                1,
                int(math.floor(tier_idx.size * SUBSAMPLE_FRACTION_PER_Y_TIER)),
            )
            selected_parts.append(
                rng.choice(tier_idx, size=sample_size, replace=False)
            )
        sampled_idx = np.concatenate(selected_parts)
        rng.shuffle(sampled_idx)

        subset = development_df.iloc[sampled_idx]
        enet_pipeline = make_feature_pipeline(
            ElasticNet(
                alpha=best_alpha,
                l1_ratio=best_l1_ratio,
                max_iter=50_000,
                tol=1e-5,
                selection="cyclic",
            )
        )
        enet_pipeline.fit(subset[elasticnet_features], subset["y_model"])
        all_coefficients = enet_pipeline.named_steps["model"].coef_
        coefficients = all_coefficients[mandatory_count:]
        selected = np.abs(coefficients) > COEF_ZERO_TOLERANCE
        counts += selected.astype(np.int64)
        abs_coef_sums += np.abs(coefficients)

        if (iteration + 1) % 100 == 0:
            print(f"  Stability selection: {iteration + 1}/{N_RESAMPLES}")

    candidate_results = pd.DataFrame(
        {
            "Feature": candidate_features,
            "Feature_Type": "ElasticNet candidate",
            "Frequency": counts,
            "Selection_Probability": counts / N_RESAMPLES,
            "Mean_Abs_Standardized_Coefficient": abs_coef_sums / N_RESAMPLES,
        }
    ).sort_values(
        by=[
            "Selection_Probability",
            "Mean_Abs_Standardized_Coefficient",
            "Feature",
        ],
        ascending=[False, False, True],
    )
    candidate_results["Candidate_Rank"] = np.arange(
        1, len(candidate_results) + 1
    )

    mandatory_results = pd.DataFrame(
        {
            "Feature": MANDATORY_FEATURES,
            "Feature_Type": "Mandatory (frequency fixed by design)",
            "Frequency": N_RESAMPLES,
            "Selection_Probability": 1.0,
            "Mean_Abs_Standardized_Coefficient": np.nan,
            "Candidate_Rank": np.nan,
        }
    )
    return pd.concat([mandatory_results, candidate_results], ignore_index=True)


def evaluate_feature_counts(
    development_df: pd.DataFrame,
    ranked_candidates: list[str],
    models: dict[str, Pipeline],
    inner_splits: list[tuple[np.ndarray, np.ndarray]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    all_records: list[dict] = []
    max_add = min(MAX_CANDIDATES_TO_ADD, len(ranked_candidates))
    y = development_df["y_model"].to_numpy()

    for k in range(max_add + 1):
        features = MANDATORY_FEATURES + ranked_candidates[:k]
        X = development_df[features]
        for model_name, model in models.items():
            try:
                predictions = cross_val_predict(
                    clone(model),
                    X,
                    y,
                    cv=inner_splits,
                    n_jobs=1,
                    method="predict",
                )
                r2 = float(r2_score(y, predictions))
                rmse = float(np.sqrt(mean_squared_error(y, predictions)))
                error = ""
            except Exception as exc:
                r2 = np.nan
                rmse = np.nan
                error = f"{type(exc).__name__}: {exc}"
                warnings.warn(
                    f"Feature count {len(features)}, model {model_name} failed: {error}"
                )
            all_records.append(
                {
                    "Feature_Count": len(features),
                    "Added_Candidate_Count": k,
                    "Method": model_name,
                    "CV_R2_log": r2,
                    "CV_RMSE_log": rmse,
                    "Error": error,
                }
            )

        current = pd.DataFrame(all_records)
        current = current[current["Feature_Count"] == len(features)].dropna(
            subset=["CV_R2_log"]
        )
        if not current.empty:
            winner = current.sort_values(
                ["CV_R2_log", "CV_RMSE_log"], ascending=[False, True]
            ).iloc[0]
            print(
                f"Feature count {len(features):2d} | "
                f"best={winner['Method']:13s} | "
                f"CV R2(log)={winner['CV_R2_log']:.4f} | "
                f"CV RMSE(log)={winner['CV_RMSE_log']:.4f}"
            )

    all_results = pd.DataFrame(all_records)
    successful = all_results.dropna(subset=["CV_R2_log"]).copy()
    if successful.empty:
        raise RuntimeError("All model evaluations failed.")

    best_by_count = (
        successful.sort_values(
            ["Feature_Count", "CV_R2_log", "CV_RMSE_log"],
            ascending=[True, False, True],
        )
        .groupby("Feature_Count", as_index=False)
        .first()
        .rename(columns={"Method": "Best_Method"})
    )
    return all_results, best_by_count


def inverse_target(log_values: np.ndarray) -> np.ndarray:
    return np.clip(np.expm1(np.asarray(log_values, dtype=float)), 0.0, None)


def plot_single_grid(
    y_log: np.ndarray,
    predictions_by_model: dict[str, np.ndarray],
    metrics_by_model: dict[str, tuple[float, float]],
    scatter_color: str,
    output_path: Path,
) -> None:
    """参考 p2 的格式绘制 3x3 单一散点图集合（全蓝或全绿，并在标题上方显示 R² 和 RMSE）"""
    fig, axes = plt.subplots(3, 3, figsize=(12, 12))
    axes = axes.flatten()
    y_true_original = inverse_target(y_log)

    for ax, (name, predictions_log) in zip(axes, predictions_by_model.items()):
        r2, rmse = metrics_by_model[name]
        y_pred_original = inverse_target(predictions_log)
        finite = np.isfinite(y_true_original) & np.isfinite(y_pred_original)
        if not finite.any():
            ax.text(0.5, 0.5, f"{name}\nNo finite predictions", ha="center")
            ax.axis("off")
            continue

        x = y_true_original[finite]
        y = y_pred_original[finite]

        # 绘制单色散点
        ax.scatter(x, y, alpha=0.6, color=scatter_color, edgecolor="none", s=30)
        ax.set_xscale("symlog", linthresh=0.1)
        ax.set_yscale("symlog", linthresh=0.1)

        max_value = max(float(np.max(x)), float(np.max(y)), 1.0)
        xmin, xmax = 0.0, max_value * 1.2
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(xmin, xmax)

        # 红色 1:1 对角虚线
        ax.plot([xmin, xmax], [xmin, xmax], "r--", lw=1.5, zorder=3)

        # 参考 p2 布局：主标题为模型名称，副标题写 R² 和 RMSE
        # ax.set_title(f"{name}\nR²: {r2:.3f} | RMSE: {rmse:.3f}", fontsize=11, fontweight="bold", pad=8)
        ax.set_title(
            f"$\mathbf{{{name}}}$\n$R^2$: {r2:.3f} | RMSE: {rmse:.3f}",
            fontsize=11,
            fontweight="normal",
            pad=8,
        )
        ax.set_xlabel("Observed DALYs", fontsize=9)
        ax.set_ylabel("Predicted DALYs", fontsize=9)
        ax.grid(True, which="major", linestyle=":", linewidth=0.6, alpha=0.7)
        ax.grid(False, which="minor")

    fig.tight_layout()
    fig.savefig(output_path, dpi=SAVEFIG_DPI, bbox_inches="tight")
    if SHOW_PLOTS:
        plt.show()
    plt.close(fig)


def main() -> None:
    if TARGET_COL not in ALL_TARGET_COLS:
        raise ValueError(f"TARGET_COL must be one of {ALL_TARGET_COLS}.")
    if not FILE_PATH.exists():
        raise FileNotFoundError(f"Excel file not found: {FILE_PATH}")

    output_dir = FILE_PATH.parent / f"FeatureSelection_{TARGET_COL}"
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Reading: {FILE_PATH}")
    df = clean_and_validate_columns(pd.read_excel(FILE_PATH))
    require_columns(
        df,
        [
            "Samples",
            "Region",
            "Economy",
            "Region_Group_Fold",
            *ALL_TARGET_COLS,
            *MANDATORY_FEATURES,
            CANDIDATE_FIRST_COL,
            CANDIDATE_LAST_COL,
        ],
    )
    df["Region_Group_Fold"] = normalize_fold_labels(df["Region_Group_Fold"])

    df[TARGET_COL] = pd.to_numeric(df[TARGET_COL], errors="coerce")
    df = df.dropna(subset=[TARGET_COL]).copy()
    if TARGET_ALREADY_LOG1P:
        df["y_model"] = df[TARGET_COL].astype(float)
    else:
        df["y_model"] = np.log1p(df[TARGET_COL].astype(float))

    development_df = df[
        df["Region_Group_Fold"].isin(DEVELOPMENT_FOLDS)
    ].copy()
    test_df = df[df["Region_Group_Fold"].eq(OUTER_TEST_FOLD)].copy()

    first_position = df.columns.get_loc(CANDIDATE_FIRST_COL)
    last_position = df.columns.get_loc(CANDIDATE_LAST_COL)
    candidate_features = df.columns[first_position : last_position + 1].tolist()

    all_feature_columns = MANDATORY_FEATURES + candidate_features
    for column in all_feature_columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    development_df = df.loc[development_df.index].copy()
    test_df = df.loc[test_df.index].copy()

    # 在 Fold 1-4 内计算零值比例过滤候选特征
    zero_ratios = development_df[candidate_features].fillna(0.0).eq(0.0).mean()
    valid_candidates = zero_ratios[
        zero_ratios <= ZERO_RATIO_THRESHOLD
    ].index.tolist()
    elasticnet_features = MANDATORY_FEATURES + valid_candidates

    filter_report = pd.DataFrame(
        {
            "Feature": candidate_features,
            "Zero_Ratio_in_fold1_to_fold4": zero_ratios.reindex(
                candidate_features
            ).to_numpy(),
        }
    )
    filter_report["Retained"] = (
        filter_report["Zero_Ratio_in_fold1_to_fold4"] <= ZERO_RATIO_THRESHOLD
    )

    inner_splits = make_predefined_four_fold_splits(
        development_df["Region_Group_Fold"]
    )

    print(f"Fast path: Fixing ElasticNet alpha={FIXED_ALPHA}, selecting l1_ratio on fold1-fold4...")
    best_l1_ratio, enet_tuning_results = tune_elastic_net_l1_ratio(
        development_df,
        elasticnet_features,
        inner_splits,
    )
    best_alpha = FIXED_ALPHA

    development_df["y_tier"] = create_y_tertiles(development_df["y_model"])

    print(f"Running {N_RESAMPLES} ElasticNet stability-selection fits on fold1-fold4...")
    stability_results = run_stability_selection(
        development_df,
        valid_candidates,
        best_alpha,
        best_l1_ratio,
    )

    stability_path = output_dir / f"ElasticNet_{TARGET_COL}.xlsx"
    with pd.ExcelWriter(stability_path, engine="openpyxl") as writer:
        stability_results.to_excel(writer, sheet_name="Selection_Frequency", index=False)
        enet_tuning_results.to_excel(writer, sheet_name="ElasticNet_CV", index=False)
        filter_report.to_excel(writer, sheet_name="Zero_Filter", index=False)

    ranked_candidates = (
        stability_results[
            stability_results["Feature_Type"].eq("ElasticNet candidate")
        ]
        .sort_values("Candidate_Rank")["Feature"]
        .tolist()
    )

    models = build_models()
    print("Evaluating feature counts up to 55 features...")
    all_model_results, best_by_count = evaluate_feature_counts(
        development_df,
        ranked_candidates,
        models,
        inner_splits,
    )

    global_best = best_by_count.sort_values(
        ["CV_R2_log", "CV_RMSE_log"], ascending=[False, True]
    ).iloc[0]
    optimal_feature_count = int(global_best["Feature_Count"])
    optimal_candidate_count = optimal_feature_count - len(MANDATORY_FEATURES)
    selected_features = MANDATORY_FEATURES + ranked_candidates[
        :optimal_candidate_count
    ]

    selected_feature_table = pd.DataFrame(
        {
            "Order": np.arange(1, len(selected_features) + 1),
            "Feature": selected_features,
            "Feature_Type": ["Mandatory"] * len(MANDATORY_FEATURES)
            + ["ElasticNet candidate"] * optimal_candidate_count,
        }
    )

    # 1. 计算并绘制 第一张图：Fold 1-4 CV 交叉验证（浅蓝色散点 #85C1E9）
    y_dev = development_df["y_model"].to_numpy()
    cv_preds, cv_metrics = {}, {}
    for name, model in models.items():
        pred = cross_val_predict(
            clone(model),
            development_df[selected_features],
            y_dev,
            cv=inner_splits,
            n_jobs=1,
        )
        cv_preds[name] = pred
        cv_metrics[name] = (
            float(r2_score(y_dev, pred)),
            float(np.sqrt(mean_squared_error(y_dev, pred))),
        )

    cv_plot_path = output_dir / f"Fold1-4_CV_Scatter_{TARGET_COL}.png"
    plot_single_grid(
        y_dev,
        cv_preds,
        cv_metrics,
        scatter_color="#85C1E9",  # 浅蓝色散点
        output_path=cv_plot_path,
    )

    # 2. 计算并绘制 第二张图：Fold 5 独立测试集（绿色散点 #7DCEA0）
    y_test = test_df["y_model"].to_numpy()
    test_preds, test_metrics = {}, {}
    fold5_records = []
    for name, model in models.items():
        fitted = clone(model).fit(development_df[selected_features], y_dev)
        pred = fitted.predict(test_df[selected_features])
        r2_val = float(r2_score(y_test, pred))
        rmse_val = float(np.sqrt(mean_squared_error(y_test, pred)))
        test_preds[name] = pred
        test_metrics[name] = (r2_val, rmse_val)
        fold5_records.append(
            {
                "Method": name,
                "Fold5_R2_log": r2_val,
                "Fold5_RMSE_log": rmse_val,
            }
        )

    fold5_plot_path = output_dir / f"Fold5_Test_Scatter_{TARGET_COL}.png"
    plot_single_grid(
        y_test,
        test_preds,
        test_metrics,
        scatter_color="#7DCEA0",  # 绿色散点
        output_path=fold5_plot_path,
    )

    best_model_path = output_dir / "BestModel.xlsx"
    with pd.ExcelWriter(best_model_path, engine="openpyxl") as writer:
        best_by_count.to_excel(writer, sheet_name="Best_By_Feature_Count", index=False)
        all_model_results.to_excel(writer, sheet_name="All_Model_CV", index=False)
        selected_feature_table.to_excel(writer, sheet_name="Selected_Features", index=False)
        pd.DataFrame(fold5_records).to_excel(writer, sheet_name="Fold5_Results", index=False)

    run_summary = {
        "target": TARGET_COL,
        "development_samples": len(development_df),
        "fold5_samples": len(test_df),
        "candidates_retained": len(valid_candidates),
        "fixed_elasticnet_alpha": FIXED_ALPHA,
        "best_elasticnet_l1_ratio": best_l1_ratio,
        "optimal_feature_count": optimal_feature_count,
        "development_selected_model": str(global_best["Best_Method"]),
    }
    summary_path = output_dir / "Run_Summary.json"
    summary_path.write_text(
        json.dumps(run_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print("\nCompleted. Output files:")
    for path in (
        stability_path,
        best_model_path,
        cv_plot_path,
        fold5_plot_path,
        summary_path,
    ):
        print(f"  {path}")


if __name__ == "__main__":
    main()
